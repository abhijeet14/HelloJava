package be.g00glen00b;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityRestServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringSecurityRestServiceApplication.class, args);
    }
}
